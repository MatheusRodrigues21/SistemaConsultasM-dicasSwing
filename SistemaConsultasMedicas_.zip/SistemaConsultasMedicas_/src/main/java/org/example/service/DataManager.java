package org.example.service;

import org.example.model.Paciente;
import org.example.model.Consulta;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class DataManager {
    private static final String PACIENTES_FILE = "pacientes.dat";
    private static final String CONSULTAS_FILE = "consultas.dat";

    private static AtomicInteger nextPacienteId = new AtomicInteger(1);
    private static AtomicInteger nextConsultaId = new AtomicInteger(1);

    public static List<Paciente> carregarPacientes() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PACIENTES_FILE))) {
            List<Paciente> pacientes = (List<Paciente>) ois.readObject();
            int max = pacientes.stream().mapToInt(Paciente::getId).max().orElse(0);
            nextPacienteId.set(max+1);
            return pacientes;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static List<Consulta> carregarConsultas() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(CONSULTAS_FILE))) {
            List<Consulta> consultas = (List<Consulta>) ois.readObject();
            int max = consultas.stream().mapToInt(Consulta::getId).max().orElse(0);
            nextConsultaId.set(max+1);
            return consultas;
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static void salvarPacientes(List<Paciente> pacientes) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PACIENTES_FILE))) {
            oos.writeObject(pacientes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void salvarConsultas(List<Consulta> consultas) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CONSULTAS_FILE))) {
            oos.writeObject(consultas);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int nextPacienteId() { return nextPacienteId.getAndIncrement(); }
    public static int nextConsultaId() { return nextConsultaId.getAndIncrement(); }
}
