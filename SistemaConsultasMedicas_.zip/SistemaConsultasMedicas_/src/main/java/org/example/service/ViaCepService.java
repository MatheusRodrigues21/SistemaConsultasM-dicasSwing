package org.example.service;

import org.example.model.Endereco;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/*
 Minimal ViaCEP fetcher that parses the JSON response via simple string matching
 (keeps project dependency-free). It performs a GET to https://viacep.com.br/ws/{cep}/json/
*/
public class ViaCepService {

    public static Endereco buscarPorCep(String cep) {
        try {
            if (cep == null) return null;
            cep = cep.replaceAll("[^0-9]", "");
            if (cep.length() != 8) {
                JOptionPane.showMessageDialog(null, "CEP inválido. Deve conter 8 dígitos.");
                return null;
            }
            String urlStr = "https://viacep.com.br/ws/" + cep + "/json/";
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            if (code != 200) {
                JOptionPane.showMessageDialog(null, "Erro ao consultar ViaCEP: HTTP " + code);
                return null;
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = in.readLine())!=null) sb.append(line);
            in.close();
            String json = sb.toString();
            if (json.contains("\"erro\"")) {
                JOptionPane.showMessageDialog(null, "CEP não encontrado.");
                return null;
            }
            Endereco e = new Endereco();
            e.setCep(extract(json, "cep"));
            e.setRua(extract(json, "logradouro"));
            e.setComplemento(extract(json, "complemento"));
            e.setBairro(extract(json, "bairro"));
            e.setCidade(extract(json, "localidade"));
            e.setUf(extract(json, "uf"));
            return e;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro na busca de CEP: " + ex.getMessage());
            return null;
        }
    }

    private static String extract(String json, String key) {
        String pattern = "\"" + key + "\":";
        int idx = json.indexOf(pattern);
        if (idx==-1) return "";
        int start = json.indexOf('"', idx + pattern.length());
        if (start==-1) return "";
        int end = json.indexOf('"', start+1);
        if (end==-1) return "";
        return json.substring(start+1, end);
    }
}
