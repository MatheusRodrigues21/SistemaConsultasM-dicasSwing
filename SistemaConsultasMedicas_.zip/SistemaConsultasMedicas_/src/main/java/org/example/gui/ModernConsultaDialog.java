package org.example.gui;

import org.example.model.Consulta;
import org.example.model.Paciente;
import static org.example.gui.ModernUIComponents.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class ModernConsultaDialog extends JDialog {
    private JComboBox<Paciente> cbPaciente;
    private ModernTextField tfDataConsulta;
    private ModernTextField tfHoraConsulta;
    private ModernTextField tfDataSolicitacao;
    private ModernTextField tfHoraSolicitacao;
    private JCheckBox chkRealizada;
    private JCheckBox chkCancelada;

    private boolean saved = false;
    private Consulta consulta;
    private List<Paciente> pacientes;

    public ModernConsultaDialog(Consulta c, Component parent, List<Paciente> pacientes) {
        super((Frame) SwingUtilities.getWindowAncestor(parent), true);
        setTitle(c == null ? "Nova Consulta" : "Editar Consulta");
        setSize(650, 600);
        setLocationRelativeTo(parent);

        this.pacientes = pacientes;
        consulta = c == null ? new Consulta() : c;

        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(Colors.BACKGROUND);

        // Header
        JPanel header = createHeader(c);
        mainPanel.add(header, BorderLayout.NORTH);

        // ScrollPane para o conteúdo
        JPanel contentWrapper = new JPanel(new BorderLayout(0, 15));
        contentWrapper.setBackground(Colors.BACKGROUND);
        contentWrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Formulário
        CardPanel formCard = new CardPanel();
        formCard.setLayout(new GridBagLayout());

        JLabel secaoConsulta = new JLabel("📋 Dados da Consulta");
        secaoConsulta.setFont(new Font("Segoe UI", Font.BOLD, 16));
        secaoConsulta.setForeground(Colors.TEXT_PRIMARY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 15, 0);
        formCard.add(secaoConsulta, gbc);

        // ComboBox de pacientes
        cbPaciente = new JComboBox<>();
        cbPaciente.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbPaciente.setBackground(Colors.SURFACE);
        cbPaciente.setForeground(Colors.TEXT_PRIMARY);
        cbPaciente.setPreferredSize(new Dimension(300, 36));

        for (Paciente p : pacientes) {
            cbPaciente.addItem(p);
        }

        // Campos de texto
        tfDataConsulta = new ModernTextField(12);
        tfHoraConsulta = new ModernTextField(8);
        tfDataSolicitacao = new ModernTextField(12);
        tfHoraSolicitacao = new ModernTextField(8);

        // Checkboxes
        chkRealizada = new JCheckBox("Consulta realizada");
        chkRealizada.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        chkRealizada.setBackground(Colors.SURFACE);
        chkRealizada.setForeground(Colors.TEXT_PRIMARY);

        chkCancelada = new JCheckBox("Consulta cancelada");
        chkCancelada.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        chkCancelada.setBackground(Colors.SURFACE);
        chkCancelada.setForeground(Colors.TEXT_PRIMARY);

        // Adiciona campos ao formulário
        addFormField(formCard, "Paciente:", cbPaciente, 1);
        addFormFieldWithHelp(formCard, "Data da Consulta:", tfDataConsulta, 2, "(dd/MM/yyyy)");
        addFormFieldWithHelp(formCard, "Hora da Consulta:", tfHoraConsulta, 3, "(HH:mm)");
        addFormFieldWithHelp(formCard, "Data Solicitação:", tfDataSolicitacao, 4, "(dd/MM/yyyy)");
        addFormFieldWithHelp(formCard, "Hora Solicitação:", tfHoraSolicitacao, 5, "(HH:mm)");

        // Adiciona checkboxes
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(15, 0, 5, 0);
        formCard.add(chkRealizada, gbc);

        gbc.gridy = 7;
        gbc.insets = new Insets(5, 0, 0, 0);
        formCard.add(chkCancelada, gbc);

        contentWrapper.add(formCard, BorderLayout.CENTER);

        // Painel de ajuda
        JPanel helpPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        helpPanel.setBackground(Colors.BACKGROUND);
        JLabel helpLabel = new JLabel("💡 Dica: A data de solicitação será preenchida automaticamente se deixada em branco");
        helpLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        helpLabel.setForeground(Colors.TEXT_SECONDARY);
        helpPanel.add(helpLabel);
        contentWrapper.add(helpPanel, BorderLayout.NORTH);

        // Botões
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.setBackground(Colors.BACKGROUND);

        ModernButton btnSalvar = new ModernButton("💾 Salvar", Colors.SUCCESS, Colors.SUCCESS_DARK);
        btnSalvar.setPreferredSize(new Dimension(140, 40));
        btnSalvar.addActionListener(ev -> salvar());

        ModernButton btnCancelar = new ModernButton("✖ Cancelar", Colors.DANGER, Colors.DANGER_DARK);
        btnCancelar.setPreferredSize(new Dimension(140, 40));
        btnCancelar.addActionListener(e -> {
            saved = false;
            setVisible(false);
        });

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);
        contentWrapper.add(buttonPanel, BorderLayout.SOUTH);

        JScrollPane scrollPane = new JScrollPane(contentWrapper);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        if (c != null) fillFromConsulta(c);

        getContentPane().add(mainPanel);
    }

    private JPanel createHeader(Consulta c) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Colors.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JLabel title = new JLabel(c == null ? "➕ Nova Consulta" : "✏️ Editar Consulta");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Preencha os dados da consulta médica");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(new Color(255, 255, 255, 180));

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setBackground(Colors.PRIMARY);
        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(subtitle);

        header.add(titlePanel, BorderLayout.WEST);
        return header;
    }

    private void addFormField(JPanel panel, String labelText, JComponent field, int row) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 0, 5, 10);

        ModernLabel label = new ModernLabel(labelText);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panel.add(field, gbc);
    }

    private void addFormFieldWithHelp(JPanel panel, String labelText, ModernTextField field, int row, String helpText) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 0, 5, 10);

        ModernLabel label = new ModernLabel(labelText);
        panel.add(label, gbc);

        JPanel fieldPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        fieldPanel.setBackground(Colors.SURFACE);
        fieldPanel.add(field);

        JLabel help = new JLabel(helpText);
        help.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        help.setForeground(Colors.TEXT_SECONDARY);
        fieldPanel.add(help);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panel.add(fieldPanel, gbc);
    }

    private void salvar() {
        // Validações
        if (cbPaciente.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this,
                    "Selecione um paciente!",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (tfDataConsulta.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "A data da consulta é obrigatória!",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE);
            tfDataConsulta.requestFocus();
            return;
        }

        if (tfHoraConsulta.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "A hora da consulta é obrigatória!",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE);
            tfHoraConsulta.requestFocus();
            return;
        }

        try {
            // Parse data e hora da consulta
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

            LocalDate dataConsulta = LocalDate.parse(tfDataConsulta.getText().trim(), dateFormatter);
            LocalTime horaConsulta = LocalTime.parse(tfHoraConsulta.getText().trim(), timeFormatter);
            LocalDateTime dataHoraConsulta = LocalDateTime.of(dataConsulta, horaConsulta);

            // Parse data e hora da solicitação (ou usa data atual)
            LocalDateTime dataHoraSolicitacao;
            if (tfDataSolicitacao.getText().trim().isEmpty() || tfHoraSolicitacao.getText().trim().isEmpty()) {
                dataHoraSolicitacao = LocalDateTime.now();
            } else {
                LocalDate dataSolicitacao = LocalDate.parse(tfDataSolicitacao.getText().trim(), dateFormatter);
                LocalTime horaSolicitacao = LocalTime.parse(tfHoraSolicitacao.getText().trim(), timeFormatter);
                dataHoraSolicitacao = LocalDateTime.of(dataSolicitacao, horaSolicitacao);
            }

            // Atualiza consulta
            consulta.setPaciente((Paciente) cbPaciente.getSelectedItem());
            consulta.setDataConsulta(dataHoraConsulta);
            consulta.setDataSolicitacao(dataHoraSolicitacao);
            consulta.setRealizada(chkRealizada.isSelected());
            consulta.setCancelada(chkCancelada.isSelected());

            saved = true;
            setVisible(false);

        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    "Formato de data/hora inválido!\n\n" +
                            "Use o formato:\n" +
                            "Data: dd/MM/yyyy (exemplo: 25/12/2024)\n" +
                            "Hora: HH:mm (exemplo: 14:30)",
                    "Erro de Formato",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void fillFromConsulta(Consulta c) {
        // Seleciona o paciente correto
        for (int i = 0; i < cbPaciente.getItemCount(); i++) {
            Paciente p = cbPaciente.getItemAt(i);
            if (p.getId() == c.getPaciente().getId()) {
                cbPaciente.setSelectedIndex(i);
                break;
            }
        }

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

        // Preenche data e hora da consulta
        if (c.getDataConsulta() != null) {
            tfDataConsulta.setText(c.getDataConsulta().format(dateFormatter));
            tfHoraConsulta.setText(c.getDataConsulta().format(timeFormatter));
        }

        // Preenche data e hora da solicitação
        if (c.getDataSolicitacao() != null) {
            tfDataSolicitacao.setText(c.getDataSolicitacao().format(dateFormatter));
            tfHoraSolicitacao.setText(c.getDataSolicitacao().format(timeFormatter));
        }

        // Preenche checkboxes
        chkRealizada.setSelected(c.isRealizada());
        chkCancelada.setSelected(c.isCancelada());
    }

    public boolean isSaved() {
        return saved;
    }

    public Consulta getConsulta() {
        return consulta;
    }
}