package org.example.gui;

import org.example.model.Paciente;
import org.example.model.Endereco;
import org.example.service.ViaCepService;
import static org.example.gui.ModernUIComponents.*;

import javax.swing.*;
import java.awt.*;

public class ModernPacienteFormDialog extends JDialog {
    private ModernTextField tfNome;
    private ModernTextField tfEmail;
    private ModernTextField tfTel;
    private ModernTextField tfCep;
    private ModernTextField tfRua;
    private ModernTextField tfNumero;
    private ModernTextField tfBairro;
    private ModernTextField tfCidade;
    private ModernTextField tfUf;
    private ModernTextField tfComplemento;

    private boolean saved = false;
    private Paciente paciente;

    public ModernPacienteFormDialog(Paciente p, Component parent) {
        super((Frame) SwingUtilities.getWindowAncestor(parent), true);
        setTitle(p == null ? "Novo Paciente" : "Editar Paciente");
        setSize(650, 700);
        setLocationRelativeTo(parent);
        paciente = p == null ? new Paciente() : p;

        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(Colors.BACKGROUND);

        // Header
        JPanel header = createHeader(p);
        mainPanel.add(header, BorderLayout.NORTH);

        // ScrollPane para o conteúdo
        JPanel contentWrapper = new JPanel(new BorderLayout(0, 15));
        contentWrapper.setBackground(Colors.BACKGROUND);
        contentWrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Formulário de dados pessoais
        CardPanel dadosPessoaisCard = new CardPanel();
        dadosPessoaisCard.setLayout(new GridBagLayout());

        JLabel secaoPessoal = new JLabel("👤 Dados Pessoais");
        secaoPessoal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        secaoPessoal.setForeground(Colors.TEXT_PRIMARY);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 15, 0);
        dadosPessoaisCard.add(secaoPessoal, gbc);

        tfNome = new ModernTextField(30);
        tfEmail = new ModernTextField(30);
        tfTel = new ModernTextField(15);

        addFormField(dadosPessoaisCard, "Nome completo:", tfNome, 1);
        addFormField(dadosPessoaisCard, "E-mail:", tfEmail, 2);
        addFormField(dadosPessoaisCard, "Telefone:", tfTel, 3);

        // Formulário de endereço
        CardPanel enderecoCard = new CardPanel();
        enderecoCard.setLayout(new GridBagLayout());

        JLabel secaoEndereco = new JLabel("📍 Endereço");
        secaoEndereco.setFont(new Font("Segoe UI", Font.BOLD, 16));
        secaoEndereco.setForeground(Colors.TEXT_PRIMARY);

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 15, 0);
        enderecoCard.add(secaoEndereco, gbc);

        tfCep = new ModernTextField(10);
        tfRua = new ModernTextField(30);
        tfNumero = new ModernTextField(6);
        tfBairro = new ModernTextField(20);
        tfCidade = new ModernTextField(20);
        tfUf = new ModernTextField(3);
        tfComplemento = new ModernTextField(30);

        // CEP com botão de busca
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 0, 5, 10);
        ModernLabel lblCep = new ModernLabel("CEP:");
        enderecoCard.add(lblCep, gbc);

        JPanel cepPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        cepPanel.setBackground(Colors.SURFACE);
        cepPanel.add(tfCep);

        ModernButton btnBuscar = new ModernButton("🔍 Buscar", Colors.PRIMARY, Colors.PRIMARY_DARK);
        btnBuscar.setPreferredSize(new Dimension(110, 36));
        btnBuscar.addActionListener(ev -> buscarCep());
        cepPanel.add(btnBuscar);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        enderecoCard.add(cepPanel, gbc);

        addFormField(enderecoCard, "Rua:", tfRua, 2);
        addFormField(enderecoCard, "Número:", tfNumero, 3);
        addFormField(enderecoCard, "Bairro:", tfBairro, 4);
        addFormField(enderecoCard, "Cidade:", tfCidade, 5);
        addFormField(enderecoCard, "UF:", tfUf, 6);
        addFormField(enderecoCard, "Complemento:", tfComplemento, 7);

        contentWrapper.add(dadosPessoaisCard, BorderLayout.NORTH);
        contentWrapper.add(enderecoCard, BorderLayout.CENTER);

        // Botões
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.setBackground(Colors.BACKGROUND);

        ModernButton btnSalvar = new ModernButton("💾 Salvar", Colors.SUCCESS, Colors.SUCCESS_DARK);
        btnSalvar.setPreferredSize(new Dimension(140, 40));
        btnSalvar.addActionListener(ev -> salvar());

        ModernButton btnCancelar = new ModernButton("✖ Cancelar", Colors.DANGER, Colors.DANGER_DARK);
        btnCancelar.setPreferredSize(new Dimension(140, 40));
        btnCancelar.addActionListener(e -> {
            saved = false;
            setVisible(false);
        });

        buttonPanel.add(btnSalvar);
        buttonPanel.add(btnCancelar);
        contentWrapper.add(buttonPanel, BorderLayout.SOUTH);

        JScrollPane scrollPane = new JScrollPane(contentWrapper);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        if (p != null) fillFromPaciente(p);

        getContentPane().add(mainPanel);
    }

    private JPanel createHeader(Paciente p) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Colors.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JLabel title = new JLabel(p == null ? "➕ Novo Paciente" : "✏️ Editar Paciente");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Preencha todos os dados do paciente");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(new Color(255, 255, 255, 180));

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setBackground(Colors.PRIMARY);
        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(subtitle);

        header.add(titlePanel, BorderLayout.WEST);
        return header;
    }

    private void addFormField(JPanel panel, String labelText, ModernTextField field, int row) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 0, 5, 10);

        ModernLabel label = new ModernLabel(labelText);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panel.add(field, gbc);
    }

    private void buscarCep() {
        String cep = tfCep.getText().trim();
        if (cep.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Digite um CEP para buscar!",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Mostra loading
        ModernButton btn = (ModernButton) ((JPanel) tfCep.getParent()).getComponent(1);
        String originalText = btn.getText();
        btn.setText("⏳ Buscando...");
        btn.setEnabled(false);

        // Busca em thread separada
        SwingWorker<Endereco, Void> worker = new SwingWorker<Endereco, Void>() {
            @Override
            protected Endereco doInBackground() {
                return ViaCepService.buscarPorCep(cep);
            }

            @Override
            protected void done() {
                btn.setText(originalText);
                btn.setEnabled(true);
                try {
                    Endereco e = get();
                    if (e != null) {
                        tfRua.setText(e.getRua());
                        tfBairro.setText(e.getBairro());
                        tfCidade.setText(e.getCidade());
                        tfUf.setText(e.getUf());
                        if (!e.getComplemento().isEmpty()) {
                            tfComplemento.setText(e.getComplemento());
                        }
                        JOptionPane.showMessageDialog(
                                ModernPacienteFormDialog.this,
                                "Endereço encontrado com sucesso!",
                                "Sucesso",
                                JOptionPane.INFORMATION_MESSAGE
                        );
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    private void salvar() {
        // Validações
        if (tfNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "O nome é obrigatório!",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE);
            tfNome.requestFocus();
            return;
        }

        paciente.setNome(tfNome.getText().trim());
        paciente.setEmail(tfEmail.getText().trim());
        paciente.setTelefone(tfTel.getText().trim());

        Endereco end = paciente.getEndereco();
        end.setCep(tfCep.getText().trim());
        end.setRua(tfRua.getText().trim());
        end.setNumero(tfNumero.getText().trim());
        end.setBairro(tfBairro.getText().trim());
        end.setCidade(tfCidade.getText().trim());
        end.setUf(tfUf.getText().trim());
        end.setComplemento(tfComplemento.getText().trim());

        saved = true;
        setVisible(false);
    }

    private void fillFromPaciente(Paciente p) {
        tfNome.setText(p.getNome());
        tfEmail.setText(p.getEmail());
        tfTel.setText(p.getTelefone());
        tfCep.setText(p.getEndereco().getCep());
        tfRua.setText(p.getEndereco().getRua());
        tfNumero.setText(p.getEndereco().getNumero());
        tfBairro.setText(p.getEndereco().getBairro());
        tfCidade.setText(p.getEndereco().getCidade());
        tfUf.setText(p.getEndereco().getUf());
        tfComplemento.setText(p.getEndereco().getComplemento());
    }

    public boolean isSaved() {
        return saved;
    }

    public Paciente getPaciente() {
        return paciente;
    }
}