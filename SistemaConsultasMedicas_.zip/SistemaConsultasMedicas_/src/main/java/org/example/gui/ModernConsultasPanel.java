package org.example.gui;

import org.example.model.Consulta;
import org.example.model.Paciente;
import org.example.service.DataManager;
import static org.example.gui.ModernUIComponents.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class ModernConsultasPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private List<Consulta> consultas;
    private List<Paciente> pacientes;
    private boolean mostrarRealizadas;

    public ModernConsultasPanel(boolean mostrarRealizadas) {
        this.mostrarRealizadas = mostrarRealizadas;
        setLayout(new BorderLayout(0, 15));
        setBackground(Colors.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        consultas = DataManager.carregarConsultas();
        pacientes = DataManager.carregarPacientes();

        // Título
        String titulo = mostrarRealizadas ? "Consultas Finalizadas" : "Consultas Agendadas";
        String subtitulo = mostrarRealizadas ?
                "Histórico de consultas concluídas e canceladas" :
                "Próximas consultas que serão realizadas";
        add(createTitlePanel(titulo, subtitulo), BorderLayout.NORTH);

        // Card principal
        CardPanel cardPanel = new CardPanel();
        cardPanel.setLayout(new BorderLayout(0, 15));

        // Painel de ações
        JPanel actionsPanel = createActionsPanel();
        cardPanel.add(actionsPanel, BorderLayout.NORTH);

        // Tabela
        String[] cols = {"ID", "Paciente", "Data da Consulta", "Data Agendamento", "Status"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        styleTable(table);

        // Ajusta largura das colunas
        table.getColumnModel().getColumn(0).setPreferredWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(220);
        table.getColumnModel().getColumn(2).setPreferredWidth(160);
        table.getColumnModel().getColumn(3).setPreferredWidth(160);
        table.getColumnModel().getColumn(4).setPreferredWidth(140);

        refreshTable();

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(Colors.BORDER, 1));
        scrollPane.getViewport().setBackground(Colors.SURFACE);
        cardPanel.add(scrollPane, BorderLayout.CENTER);

        // Painel de informações
        JPanel infoPanel = createInfoPanel();
        cardPanel.add(infoPanel, BorderLayout.SOUTH);

        add(cardPanel, BorderLayout.CENTER);
    }

    private JPanel createActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        panel.setBackground(Colors.SURFACE);

        if (!mostrarRealizadas) {
            // Botões para consultas pendentes
            ModernButton btnAdd = new ModernButton("➕ Agendar Consulta", Colors.PRIMARY, Colors.PRIMARY_DARK);
            ModernButton btnEdit = new ModernButton("✏️ Editar", Colors.WARNING, Colors.WARNING_DARK);
            ModernButton btnRealizar = new ModernButton("✅ Finalizar", Colors.SUCCESS, Colors.SUCCESS_DARK);
            ModernButton btnCancelar = new ModernButton("❌ Cancelar", Colors.DANGER, Colors.DANGER_DARK);
            ModernButton btnDel = new ModernButton("🗑️ Excluir", Colors.DANGER, Colors.DANGER_DARK);

            btnAdd.setPreferredSize(new Dimension(160, 40));
            btnRealizar.setPreferredSize(new Dimension(130, 40));

            btnAdd.addActionListener(e -> adicionarConsulta());
            btnEdit.addActionListener(e -> editarConsulta());
            btnRealizar.addActionListener(e -> marcarComoRealizada());
            btnCancelar.addActionListener(e -> cancelarConsulta());
            btnDel.addActionListener(e -> excluirConsulta());

            panel.add(btnAdd);
            panel.add(btnEdit);
            panel.add(btnRealizar);
            panel.add(btnCancelar);
            panel.add(btnDel);
        } else {
            // Botões para consultas finalizadas
            ModernButton btnView = new ModernButton("👁️ Ver Detalhes", Colors.PRIMARY, Colors.PRIMARY_DARK);
            ModernButton btnDel = new ModernButton("🗑️ Excluir do Histórico", Colors.DANGER, Colors.DANGER_DARK);

            btnDel.setPreferredSize(new Dimension(180, 40));

            btnView.addActionListener(e -> verDetalhes());
            btnDel.addActionListener(e -> excluirConsulta());

            panel.add(btnView);
            panel.add(btnDel);
        }

        return panel;
    }

    private JPanel createInfoPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        panel.setBackground(Colors.SURFACE);

        List<Consulta> filtradas = filtrarConsultas();

        if (!mostrarRealizadas) {
            JLabel infoLabel = new JLabel("📋 " + filtradas.size() + " consulta(s) agendada(s)");
            infoLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
            infoLabel.setForeground(Colors.PRIMARY);
            panel.add(infoLabel);
        } else {
            long realizadas = filtradas.stream().filter(Consulta::isRealizada).count();
            long canceladas = filtradas.stream().filter(Consulta::isCancelada).count();

            JLabel realizadasLabel = new JLabel("✅ " + realizadas + " realizada(s)");
            realizadasLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
            realizadasLabel.setForeground(Colors.SUCCESS);

            JLabel canceladasLabel = new JLabel("❌ " + canceladas + " cancelada(s)");
            canceladasLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
            canceladasLabel.setForeground(Colors.DANGER);

            panel.add(realizadasLabel);
            panel.add(canceladasLabel);
        }

        return panel;
    }

    private void adicionarConsulta() {
        if (pacientes.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Você precisa cadastrar pelo menos um paciente antes de agendar consultas!\n\n" +
                            "Vá até a aba 'Pacientes' e cadastre um novo paciente.",
                    "Nenhum Paciente Cadastrado",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        ModernConsultaDialog dlg = new ModernConsultaDialog(null, this, pacientes);
        dlg.setVisible(true);
        if (dlg.isSaved()) {
            Consulta c = dlg.getConsulta();
            c.setId(DataManager.nextConsultaId());
            consultas.add(c);
            DataManager.salvarConsultas(consultas);
            refreshTable();
            showSuccessMessage("Consulta agendada com sucesso!");
        }
    }

    private void editarConsulta() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione uma consulta primeiro");
            return;
        }

        List<Consulta> filtradas = filtrarConsultas();
        Consulta c = filtradas.get(row);

        ModernConsultaDialog dlg = new ModernConsultaDialog(c, this, pacientes);
        dlg.setVisible(true);
        if (dlg.isSaved()) {
            DataManager.salvarConsultas(consultas);
            refreshTable();
            showSuccessMessage("Consulta atualizada com sucesso!");
        }
    }

    private void marcarComoRealizada() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione uma consulta primeiro");
            return;
        }

        List<Consulta> filtradas = filtrarConsultas();
        Consulta c = filtradas.get(row);

        if (c.isCancelada()) {
            showWarningMessage("Não é possível finalizar uma consulta que foi cancelada!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Confirmar que a consulta foi realizada com sucesso?",
                "Finalizar Consulta",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            c.setRealizada(true);
            DataManager.salvarConsultas(consultas);
            refreshTable();
            showSuccessMessage("Consulta finalizada com sucesso!");
        }
    }

    private void cancelarConsulta() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione uma consulta primeiro");
            return;
        }

        List<Consulta> filtradas = filtrarConsultas();
        Consulta c = filtradas.get(row);

        if (c.isRealizada()) {
            showWarningMessage("Não é possível cancelar uma consulta que já foi realizada!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Deseja realmente cancelar esta consulta?",
                "Cancelar Consulta",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            c.setCancelada(true);
            DataManager.salvarConsultas(consultas);
            refreshTable();
            showSuccessMessage("Consulta cancelada!");
        }
    }

    private void verDetalhes() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione uma consulta primeiro");
            return;
        }

        List<Consulta> filtradas = filtrarConsultas();
        Consulta c = filtradas.get(row);

        // Dialog de detalhes
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Detalhes da Consulta", true);
        dialog.setSize(580, 520);
        dialog.setLocationRelativeTo(this);

        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(Colors.BACKGROUND);
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Colors.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("📋 Detalhes da Consulta");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);

        JLabel idLabel = new JLabel("Código: #" + c.getId());
        idLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        idLabel.setForeground(new Color(255, 255, 255, 200));

        JPanel headerText = new JPanel();
        headerText.setLayout(new BoxLayout(headerText, BoxLayout.Y_AXIS));
        headerText.setBackground(Colors.PRIMARY);
        headerText.add(titleLabel);
        headerText.add(idLabel);

        header.add(headerText, BorderLayout.WEST);
        content.add(header, BorderLayout.NORTH);

        // Conteúdo
        CardPanel infoCard = new CardPanel();
        infoCard.setLayout(new GridLayout(8, 1, 0, 12));

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm");

        infoCard.add(createInfoRow("👤 Paciente:", c.getPaciente().getNome()));
        infoCard.add(createInfoRow("📧 Email:", c.getPaciente().getEmail()));
        infoCard.add(createInfoRow("📞 Telefone:", c.getPaciente().getTelefone()));
        infoCard.add(createInfoRow("📅 Data da Consulta:",
                c.getDataConsulta() != null ? c.getDataConsulta().format(fmt) : "-"));
        infoCard.add(createInfoRow("📝 Data do Agendamento:",
                c.getDataSolicitacao() != null ? c.getDataSolicitacao().format(fmt) : "-"));

        String status = c.isCancelada() ? "❌ Cancelada" : (c.isRealizada() ? "✅ Realizada" : "⏳ Agendada");
        Color statusColor = c.isCancelada() ? Colors.DANGER : (c.isRealizada() ? Colors.SUCCESS : Colors.WARNING);

        JPanel statusPanel = new JPanel(new BorderLayout(10, 0));
        statusPanel.setBackground(Colors.SURFACE);

        JLabel lblStatus = new JLabel("📊 Status:");
        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblStatus.setForeground(Colors.TEXT_SECONDARY);
        lblStatus.setPreferredSize(new Dimension(150, 20));

        JLabel badgeStatus = createBadge(status, statusColor);
        badgeStatus.setPreferredSize(new Dimension(140, 30));

        statusPanel.add(lblStatus, BorderLayout.WEST);
        statusPanel.add(badgeStatus, BorderLayout.CENTER);

        infoCard.add(statusPanel);

        content.add(infoCard, BorderLayout.CENTER);

        // Botão fechar
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Colors.BACKGROUND);
        ModernButton btnClose = new ModernButton("Fechar", Colors.PRIMARY, Colors.PRIMARY_DARK);
        btnClose.setPreferredSize(new Dimension(140, 40));
        btnClose.addActionListener(e -> dialog.dispose());
        buttonPanel.add(btnClose);
        content.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(content);
        dialog.setVisible(true);
    }

    private JPanel createInfoRow(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout(10, 0));
        panel.setBackground(Colors.SURFACE);

        JLabel lblLabel = new JLabel(label);
        lblLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblLabel.setForeground(Colors.TEXT_SECONDARY);
        lblLabel.setPreferredSize(new Dimension(150, 20));

        JLabel lblValue = new JLabel(value);
        lblValue.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblValue.setForeground(Colors.TEXT_PRIMARY);

        panel.add(lblLabel, BorderLayout.WEST);
        panel.add(lblValue, BorderLayout.CENTER);

        return panel;
    }

    private void excluirConsulta() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione uma consulta primeiro");
            return;
        }

        String mensagem = mostrarRealizadas ?
                "Deseja realmente excluir esta consulta do histórico?" :
                "Deseja realmente excluir esta consulta agendada?";

        int confirm = JOptionPane.showConfirmDialog(
                this,
                mensagem,
                "Confirmar Exclusão",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            List<Consulta> filtradas = filtrarConsultas();
            Consulta c = filtradas.get(row);
            consultas.remove(c);
            DataManager.salvarConsultas(consultas);
            refreshTable();
            showSuccessMessage("Consulta excluída com sucesso!");
        }
    }

    private List<Consulta> filtrarConsultas() {
        if (mostrarRealizadas) {
            return consultas.stream()
                    .filter(c -> c.isRealizada() || c.isCancelada())
                    .collect(Collectors.toList());
        } else {
            return consultas.stream()
                    .filter(c -> !c.isRealizada() && !c.isCancelada())
                    .collect(Collectors.toList());
        }
    }

    private void refreshTable() {
        model.setRowCount(0);
        List<Consulta> filtradas = filtrarConsultas();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (Consulta c : filtradas) {
            String status;
            if (c.isCancelada()) {
                status = "❌ Cancelada";
            } else if (c.isRealizada()) {
                status = "✅ Realizada";
            } else {
                status = "⏳ Agendada";
            }

            model.addRow(new Object[]{
                    c.getId(),
                    c.getPaciente().getNome(),
                    c.getDataConsulta() != null ? c.getDataConsulta().format(fmt) : "-",
                    c.getDataSolicitacao() != null ? c.getDataSolicitacao().format(fmt) : "-",
                    status
            });
        }
    }

    private void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWarningMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Atenção", JOptionPane.WARNING_MESSAGE);
    }
}