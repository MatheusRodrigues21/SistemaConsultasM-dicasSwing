package org.example.gui;

import javax.swing.*;
import java.awt.*;
import static org.example.gui.ModernUIComponents.Colors;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("Sistema de Consultas Médicas");
        setSize(1200, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Define look and feel moderno
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Container principal
        JPanel mainContainer = new JPanel(new BorderLayout());
        mainContainer.setBackground(Colors.BACKGROUND);

        // Header humanizado
        JPanel header = createHeader();
        mainContainer.add(header, BorderLayout.NORTH);

        // Tabs modernizadas
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabs.setBackground(Colors.BACKGROUND);
        tabs.setForeground(Colors.TEXT_PRIMARY);

        // Customiza a aparência das tabs
        UIManager.put("TabbedPane.selected", Colors.PRIMARY_LIGHT);
        UIManager.put("TabbedPane.contentAreaColor", Colors.SURFACE);
        UIManager.put("TabbedPane.borderHightlightColor", Colors.BORDER);

        tabs.addTab("📅 Consultas Pendentes", new ModernConsultasPanel(false));
        tabs.addTab("✅ Consultas Realizadas", new ModernConsultasPanel(true));
        tabs.addTab("👥 Pacientes", new ModernPacientesPanel());

        // Aumenta a altura das tabs
        tabs.setPreferredSize(new Dimension(tabs.getPreferredSize().width, 55));

        mainContainer.add(tabs, BorderLayout.CENTER);

        add(mainContainer);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Colors.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(28, 40, 28, 40));

        // Painel esquerdo com título e subtítulo
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(Colors.PRIMARY);

        // Título principal
        JLabel title = new JLabel("🏥 Sistema de Consultas Médicas");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(Color.WHITE);

        // Subtítulo
        JLabel subtitle = new JLabel("Cuidando da saúde com organização e carinho");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        subtitle.setForeground(new Color(255, 255, 255, 200));

        leftPanel.add(title);
        leftPanel.add(Box.createVerticalStrut(8));
        leftPanel.add(subtitle);

        // Painel direito com informações adicionais
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        rightPanel.setBackground(Colors.PRIMARY);

        // Card de boas-vindas
        JPanel welcomeCard = createWelcomeCard();
        rightPanel.add(welcomeCard);

        header.add(leftPanel, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);

        return header;
    }

    private JPanel createWelcomeCard() {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(255, 255, 255, 30));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 255, 255, 50), 1),
                BorderFactory.createEmptyBorder(12, 20, 12, 20)
        ));

        JLabel dateLabel = new JLabel("📆 " + java.time.LocalDate.now().format(
                java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")
        ));
        dateLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        dateLabel.setForeground(Color.WHITE);

        JLabel timeLabel = new JLabel("🕐 " + java.time.LocalTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("HH:mm")
        ));
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        timeLabel.setForeground(new Color(255, 255, 255, 200));

        card.add(dateLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(timeLabel);

        return card;
    }
}