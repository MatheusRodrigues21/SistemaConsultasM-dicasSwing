package org.example.gui;

import org.example.model.Paciente;
import org.example.model.Endereco;
import org.example.service.DataManager;
import static org.example.gui.ModernUIComponents.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ModernPacientesPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private List<Paciente> pacientes;

    public ModernPacientesPanel() {
        setLayout(new BorderLayout(0, 15));
        setBackground(Colors.BACKGROUND);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        pacientes = DataManager.carregarPacientes();

        // Título
        add(createTitlePanel("Pacientes", "Gerencie os dados dos seus pacientes"), BorderLayout.NORTH);

        // Card principal
        CardPanel cardPanel = new CardPanel();
        cardPanel.setLayout(new BorderLayout(0, 15));

        // Painel de ações
        JPanel actionsPanel = createActionsPanel();
        cardPanel.add(actionsPanel, BorderLayout.NORTH);

        // Tabela
        String[] cols = {"ID", "Nome", "Email", "Telefone"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        styleTable(table);

        refreshTable();

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(Colors.BORDER, 1));
        scrollPane.getViewport().setBackground(Colors.SURFACE);
        cardPanel.add(scrollPane, BorderLayout.CENTER);

        // Painel de informações
        JPanel infoPanel = createInfoPanel();
        cardPanel.add(infoPanel, BorderLayout.SOUTH);

        add(cardPanel, BorderLayout.CENTER);
    }

    private JPanel createActionsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panel.setBackground(Colors.SURFACE);

        ModernButton btnAdd = new ModernButton("➕ Novo Paciente", Colors.PRIMARY, Colors.PRIMARY_DARK);
        ModernButton btnEdit = new ModernButton("✏️ Editar", Colors.WARNING, Colors.WARNING_DARK);
        ModernButton btnView = new ModernButton("📍 Ver Endereço", Colors.SUCCESS, Colors.SUCCESS_DARK);
        ModernButton btnDel = new ModernButton("🗑️ Excluir", Colors.DANGER, Colors.DANGER_DARK);

        btnAdd.addActionListener(e -> adicionarPaciente());
        btnEdit.addActionListener(e -> editarPaciente());
        btnView.addActionListener(e -> verEndereco());
        btnDel.addActionListener(e -> excluirPaciente());

        panel.add(btnAdd);
        panel.add(btnEdit);
        panel.add(btnView);
        panel.add(btnDel);

        return panel;
    }

    private JPanel createInfoPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBackground(Colors.SURFACE);

        JLabel infoLabel = new JLabel("💡 Dica: Selecione um paciente para ver mais opções");
        infoLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        infoLabel.setForeground(Colors.TEXT_SECONDARY);

        panel.add(infoLabel);
        return panel;
    }

    private void adicionarPaciente() {
        ModernPacienteFormDialog dlg = new ModernPacienteFormDialog(null, this);
        dlg.setVisible(true);
        if (dlg.isSaved()) {
            Paciente p = dlg.getPaciente();
            p.setId(DataManager.nextPacienteId());
            pacientes.add(p);
            DataManager.salvarPacientes(pacientes);
            refreshTable();
            showSuccessMessage("Paciente cadastrado com sucesso!");
        }
    }

    private void editarPaciente() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione um paciente primeiro");
            return;
        }

        Paciente p = pacientes.get(row);
        ModernPacienteFormDialog dlg = new ModernPacienteFormDialog(p, this);
        dlg.setVisible(true);
        if (dlg.isSaved()) {
            DataManager.salvarPacientes(pacientes);
            refreshTable();
            showSuccessMessage("Paciente atualizado com sucesso!");
        }
    }

    private void verEndereco() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione um paciente primeiro");
            return;
        }

        Paciente p = pacientes.get(row);
        Endereco end = p.getEndereco();

        // Dialog customizado para exibir endereço
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Endereço do Paciente", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);

        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(Colors.BACKGROUND);
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Colors.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("📍 Endereço");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);

        JLabel nameLabel = new JLabel(p.getNome());
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameLabel.setForeground(new Color(255, 255, 255, 180));

        JPanel headerText = new JPanel();
        headerText.setLayout(new BoxLayout(headerText, BoxLayout.Y_AXIS));
        headerText.setBackground(Colors.PRIMARY);
        headerText.add(titleLabel);
        headerText.add(nameLabel);

        header.add(headerText, BorderLayout.WEST);
        content.add(header, BorderLayout.NORTH);

        // Conteúdo
        CardPanel infoCard = new CardPanel();
        infoCard.setLayout(new GridLayout(7, 1, 0, 10));

        infoCard.add(createInfoRow("CEP:", end.getCep()));
        infoCard.add(createInfoRow("Rua:", end.getRua()));
        infoCard.add(createInfoRow("Número:", end.getNumero()));
        infoCard.add(createInfoRow("Bairro:", end.getBairro()));
        infoCard.add(createInfoRow("Cidade:", end.getCidade()));
        infoCard.add(createInfoRow("UF:", end.getUf()));
        infoCard.add(createInfoRow("Complemento:", end.getComplemento().isEmpty() ? "-" : end.getComplemento()));

        content.add(infoCard, BorderLayout.CENTER);

        // Botão fechar
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Colors.BACKGROUND);
        ModernButton btnClose = new ModernButton("Fechar", Colors.PRIMARY, Colors.PRIMARY_DARK);
        btnClose.addActionListener(e -> dialog.dispose());
        buttonPanel.add(btnClose);
        content.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(content);
        dialog.setVisible(true);
    }

    private JPanel createInfoRow(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout(10, 0));
        panel.setBackground(Colors.SURFACE);

        JLabel lblLabel = new JLabel(label);
        lblLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblLabel.setForeground(Colors.TEXT_SECONDARY);
        lblLabel.setPreferredSize(new Dimension(100, 20));

        JLabel lblValue = new JLabel(value);
        lblValue.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblValue.setForeground(Colors.TEXT_PRIMARY);

        panel.add(lblLabel, BorderLayout.WEST);
        panel.add(lblValue, BorderLayout.CENTER);

        return panel;
    }

    private void excluirPaciente() {
        int row = table.getSelectedRow();
        if (row == -1) {
            showWarningMessage("Selecione um paciente primeiro");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Deseja realmente excluir este paciente?",
                "Confirmar Exclusão",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            pacientes.remove(row);
            DataManager.salvarPacientes(pacientes);
            refreshTable();
            showSuccessMessage("Paciente excluído com sucesso!");
        }
    }

    private void refreshTable() {
        model.setRowCount(0);
        for (Paciente p : pacientes) {
            model.addRow(new Object[]{
                    p.getId(),
                    p.getNome(),
                    p.getEmail(),
                    p.getTelefone()
            });
        }
    }

    private void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWarningMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Atenção", JOptionPane.WARNING_MESSAGE);
    }
}