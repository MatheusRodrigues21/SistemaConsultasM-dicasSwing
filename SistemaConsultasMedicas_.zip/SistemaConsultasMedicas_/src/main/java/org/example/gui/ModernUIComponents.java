package org.example.gui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.geom.*;

/**
 * Componentes UI modernos e humanizados para o sistema
 */
public class ModernUIComponents {

    // Paleta de cores humanizada e acolhedora
    public static class Colors {
        // Cores principais - tons suaves e amigáveis
        public static final Color PRIMARY = new Color(88, 166, 255); // Azul céu suave
        public static final Color PRIMARY_DARK = new Color(64, 140, 230);
        public static final Color PRIMARY_LIGHT = new Color(179, 217, 255);
        public static final Color PRIMARY_ULTRA_LIGHT = new Color(230, 242, 255);

        // Cores de sucesso - verde natural
        public static final Color SUCCESS = new Color(72, 187, 120);
        public static final Color SUCCESS_DARK = new Color(56, 161, 105);
        public static final Color SUCCESS_LIGHT = new Color(198, 246, 213);

        // Cores de perigo - vermelho suave
        public static final Color DANGER = new Color(252, 129, 129);
        public static final Color DANGER_DARK = new Color(245, 101, 101);
        public static final Color DANGER_LIGHT = new Color(254, 215, 215);

        // Cores de aviso - laranja caloroso
        public static final Color WARNING = new Color(251, 191, 36);
        public static final Color WARNING_DARK = new Color(245, 158, 11);
        public static final Color WARNING_LIGHT = new Color(254, 243, 199);

        // Cores de fundo - tons neutros e acolhedores
        public static final Color BACKGROUND = new Color(250, 251, 252);
        public static final Color SURFACE = Color.WHITE;
        public static final Color BORDER = new Color(229, 231, 235);
        public static final Color HOVER = new Color(243, 244, 246);

        // Cores de texto - legíveis e confortáveis
        public static final Color TEXT_PRIMARY = new Color(31, 41, 55);
        public static final Color TEXT_SECONDARY = new Color(107, 114, 128);
        public static final Color TEXT_DISABLED = new Color(209, 213, 219);

        // Cores especiais
        public static final Color ACCENT = new Color(147, 51, 234); // Roxo para destaques
        public static final Color INFO = new Color(59, 130, 246); // Azul informativo
    }

    /**
     * Botão moderno com cantos mais arredondados e sombras suaves
     */
    public static class ModernButton extends JButton {
        private Color baseColor;
        private Color hoverColor;
        private boolean isHovered = false;
        private float shadowAlpha = 0.15f;

        public ModernButton(String text, Color color, Color hoverColor) {
            super(text);
            this.baseColor = color;
            this.hoverColor = hoverColor;
            setupStyle();
        }

        private void setupStyle() {
            setForeground(Color.WHITE);
            setBackground(baseColor);
            setFocusPainted(false);
            setBorderPainted(false);
            setFont(new Font("Segoe UI", Font.BOLD, 13));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(130, 40));

            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    isHovered = true;
                    setBackground(hoverColor);
                    shadowAlpha = 0.25f;
                    repaint();
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    isHovered = false;
                    setBackground(baseColor);
                    shadowAlpha = 0.15f;
                    repaint();
                }
            });

            setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Sombra suave
            g2.setColor(new Color(0, 0, 0, (int)(shadowAlpha * 255)));
            g2.fill(new RoundRectangle2D.Float(2, 3, getWidth()-4, getHeight()-3, 12, 12));

            // Botão
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-4, 12, 12));

            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Painel com sombra e bordas mais arredondadas
     */
    public static class CardPanel extends JPanel {
        public CardPanel() {
            setBackground(Colors.SURFACE);
            setBorder(BorderFactory.createCompoundBorder(
                    new SoftShadowBorder(),
                    BorderFactory.createEmptyBorder(24, 24, 24, 24)
            ));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Float(2, 2, getWidth()-5, getHeight()-5, 16, 16));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Borda com sombra mais suave e natural
     */
    static class SoftShadowBorder extends AbstractBorder {
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Múltiplas camadas de sombra para efeito mais suave
            for (int i = 0; i < 4; i++) {
                int alpha = 5 - i;
                g2.setColor(new Color(0, 0, 0, alpha));
                g2.draw(new RoundRectangle2D.Float(x+i+1, y+i+2, width-2*(i+1)-2, height-2*(i+1)-3, 16, 16));
            }

            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(5, 5, 8, 5);
        }
    }

    /**
     * Campo de texto com design mais amigável
     */
    public static class ModernTextField extends JTextField {
        private boolean isFocused = false;

        public ModernTextField(int columns) {
            super(columns);
            setupStyle();
        }

        private void setupStyle() {
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setForeground(Colors.TEXT_PRIMARY);
            setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(Colors.BORDER),
                    BorderFactory.createEmptyBorder(10, 14, 10, 14)
            ));
            setBackground(Colors.SURFACE);
            setCaretColor(Colors.PRIMARY);

            addFocusListener(new java.awt.event.FocusAdapter() {
                public void focusGained(java.awt.event.FocusEvent evt) {
                    isFocused = true;
                    setBorder(BorderFactory.createCompoundBorder(
                            new RoundedBorder(Colors.PRIMARY),
                            BorderFactory.createEmptyBorder(10, 14, 10, 14)
                    ));
                    repaint();
                }
                public void focusLost(java.awt.event.FocusEvent evt) {
                    isFocused = false;
                    setBorder(BorderFactory.createCompoundBorder(
                            new RoundedBorder(Colors.BORDER),
                            BorderFactory.createEmptyBorder(10, 14, 10, 14)
                    ));
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Borda arredondada suave
     */
    static class RoundedBorder extends AbstractBorder {
        private Color color;

        public RoundedBorder(Color color) {
            this.color = color;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(2f));
            g2.draw(new RoundRectangle2D.Float(x+1, y+1, width-3, height-3, 8, 8));
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(3, 3, 3, 3);
        }
    }

    /**
     * Label moderno e amigável
     */
    public static class ModernLabel extends JLabel {
        public ModernLabel(String text) {
            super(text);
            setFont(new Font("Segoe UI", Font.BOLD, 13));
            setForeground(Colors.TEXT_PRIMARY);
        }
    }

    /**
     * Renderer customizado para tabelas com design mais humano
     */
    public static class ModernTableCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {

            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            if (isSelected) {
                c.setBackground(Colors.PRIMARY_ULTRA_LIGHT);
                c.setForeground(Colors.TEXT_PRIMARY);
            } else {
                c.setBackground(row % 2 == 0 ? Colors.SURFACE : new Color(249, 250, 251));
                c.setForeground(Colors.TEXT_PRIMARY);
            }

            setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
            setFont(new Font("Segoe UI", Font.PLAIN, 13));

            return c;
        }
    }

    /**
     * Estilização humanizada de tabela
     */
    public static void styleTable(JTable table) {
        table.setRowHeight(48);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(Colors.TEXT_PRIMARY);
        table.setSelectionBackground(Colors.PRIMARY_ULTRA_LIGHT);
        table.setSelectionForeground(Colors.TEXT_PRIMARY);
        table.setGridColor(new Color(243, 244, 246));
        table.setShowVerticalLines(true);
        table.setShowHorizontalLines(true);
        table.setIntercellSpacing(new Dimension(0, 1));

        // Header estilizado com gradiente suave
        JTableHeader header = table.getTableHeader();
        header.setBackground(Colors.PRIMARY);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setPreferredSize(new Dimension(header.getWidth(), 50));

        header.setDefaultRenderer(new TableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = new JLabel(value.toString());
                label.setFont(new Font("Segoe UI", Font.BOLD, 13));
                label.setForeground(Color.WHITE);
                label.setBackground(Colors.PRIMARY);
                label.setOpaque(true);
                label.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 16));
                return label;
            }
        });

        // Aplicar renderer customizado
        ModernTableCellRenderer renderer = new ModernTableCellRenderer();
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
    }

    /**
     * Cria um painel de título humanizado
     */
    public static JPanel createTitlePanel(String title, String subtitle) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Colors.BACKGROUND);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Colors.TEXT_PRIMARY);

        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        subtitleLabel.setForeground(Colors.TEXT_SECONDARY);

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(Colors.BACKGROUND);
        textPanel.add(titleLabel);
        textPanel.add(Box.createVerticalStrut(6));
        textPanel.add(subtitleLabel);

        panel.add(textPanel, BorderLayout.WEST);

        return panel;
    }

    /**
     * Cria badge/tag colorido mais arredondado
     */
    public static JLabel createBadge(String text, Color bgColor) {
        JLabel badge = new JLabel(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bgColor);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setForeground(Color.WHITE);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 12));
        badge.setHorizontalAlignment(SwingConstants.CENTER);
        badge.setBorder(BorderFactory.createEmptyBorder(6, 16, 6, 16));
        badge.setOpaque(false);
        return badge;
    }

    /**
     * Cria um separador visual suave
     */
    public static JSeparator createSoftSeparator() {
        JSeparator separator = new JSeparator();
        separator.setForeground(Colors.BORDER);
        separator.setBackground(Colors.BORDER);
        return separator;
    }

    /**
     * Cria um painel de informação com ícone
     */
    public static JPanel createInfoPanel(String icon, String text, Color color) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        panel.setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue(), 30));
        panel.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(new Color(color.getRed(), color.getGreen(), color.getBlue(), 100)),
                BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI", Font.PLAIN, 20));

        JLabel textLabel = new JLabel(text);
        textLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textLabel.setForeground(Colors.TEXT_PRIMARY);

        panel.add(iconLabel);
        panel.add(textLabel);

        return panel;
    }
}